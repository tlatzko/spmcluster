=====
Usage
=====

To use spmcluster in a project::

	import spm
