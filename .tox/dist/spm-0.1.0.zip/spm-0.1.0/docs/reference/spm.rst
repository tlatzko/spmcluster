spm
===

.. automodule:: spm
    :members:
